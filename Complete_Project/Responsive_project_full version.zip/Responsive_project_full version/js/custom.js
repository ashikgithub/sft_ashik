
function myFunction() {
    document.getElementsByClassName("topnav")[0].classList.toggle("responsive");
}
